<?php
include ('test.php');
?>
<div class="container">
<?php
    $db = new DB();
    $db->getBaselines();
    $error_counts =  $db->getErrorCounts();
    $info_counts =  $db->getInformationCounts();
    $warning_counts =  $db->getWarningCounts();

    $errors = $db->getErrors();
    $error_dataPoints= array(
        array("y" => $error_counts[0], "label" => "Critical"),
        array("y" => $error_counts[1], "label" => "High"),
        array("y" => $error_counts[2], "label" => "Low"),
    );
    $info_dataPoints= array(
        array("y" => $info_counts[0], "label" => "Critical"),
        array("y" => $info_counts[1], "label" => "High"),
        array("y" => $info_counts[2], "label" => "Low"),
    );
    $warning_dataPoints= array(
        array("y" => $warning_counts[0], "label" => "Critical"),
        array("y" => $warning_counts[1], "label" => "High"),
        array("y" => $warning_counts[2], "label" => "Low"),
    );
?>

<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	title: {
		text: "Log level severity"
	},
	axisY: {
		title: "Occurences"
	},
	data: [
    {
		type: "line",
        name:"Errors",
        showInLegend: true,
		dataPoints: <?php echo json_encode($error_dataPoints, JSON_NUMERIC_CHECK); ?>
	},
    {
		type: "line",
        name:"Information",
        showInLegend: true,
		dataPoints: <?php echo json_encode($info_dataPoints, JSON_NUMERIC_CHECK); ?>
	},
    {
		type: "line",
        name:"Warnings",
        showInLegend: true,
		dataPoints: <?php echo json_encode($warning_dataPoints, JSON_NUMERIC_CHECK); ?>
	},

]
});

chart.render();
 
}
</script>
<div class="row col-md-12 col-sm-12 card card-body">
<div id="chartContainer" style="height: 350px; width: 950px;"></div>
<!-- <div id="chartContainer2" style="height: 350px; width: 950px;"></div> -->

</div>
<!-- <hr>
<div class="row">
<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#errors" type="button" role="tab" aria-controls="home" aria-selected="true"> All Errors <span class="badge bg-danger"><?php echo count($db->getErrors());?></span></button>
  </li> -->
  <!-- <li class="nav-item" role="presentation">
    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Profile</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Contact</button>
  </li> -->
<!-- </ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="errors" role="tabpanel" aria-labelledby="home-tab">
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Date</th>
                <th>Time</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody> -->
            <?php
            // foreach($errors as $e){
            //     echo "<tr><td>".$e['level']."</td></tr>";
            // }
            ?>
        </tbody>
    </table>
  </div>
</div>
</div>
</div>