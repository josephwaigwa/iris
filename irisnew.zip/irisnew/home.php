<?php require_once 'assets/php/admin-header.php'; 
include ('db.php');
?>
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Summary</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="container">
     <div class="row">
      <div class="col-sm">
        <p><p>
        <div class="card">
          <div class="card-body">
            <h2><b>Total Logs</b></h2>
            <hr>
          
            <div class="row">
              <div class="col-sm">
              <?php
               $sql="SELECT COUNT(*) FROM `app`";
               $res = $conn->query($sql);
               $row=mysqli_fetch_array($res);

               $sql1="SELECT COUNT(*) FROM `system`";
               $res1 = $conn->query($sql1);
               $row1=mysqli_fetch_array($res1);

               
               $sql2="SELECT COUNT(*) FROM `adsecurity`";
               $res2 = $conn->query($sql2);
               $row2=mysqli_fetch_array($res2);
               ?>
                             
                <p>Application Entries:<?php echo $row[0];?> | System Entries:<?php echo $row1[0];?> |  AD Entries:<?php echo $row2[0];?><p>
              </div>             
            </div>
          </div>
        </div>
        
      </div>
      <div class="col-sm-12"> 
      <p><p>
      <h3><b>Alert category</b><h3>
  <div class="list-group">
    <a href="#" class="list-group-item list-group-item-action flex-column align-items-start"><!--active-->
      <div class="d-flex w-100 justify-content-between">              
      <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                 <tr>
                  <th>Event ID</th>
                  
                  <th>Activity</th>
                  <th>Count</th>
                 </tr>
               </thead>
               <tbody>
               <?php
               $sql = "SELECT level, COUNT(level), event_id FROM adsecurity WHERE event_id = '4720' ";
              // $sql = "SELECT level, COUNT(level), event_id FROM adsecurity WHERE event_id = '4726' ";
               $result = $conn->query($sql);

                while($row = mysqli_fetch_array($result)){
                  ?>
                  <tr>
                  <td><?php echo $row['event_id']; ?></td>
                  <td><h5>User created<h5></td> 
                  <td><?php echo $row['COUNT(level)']; ?></td>
                  </tr>

                <?php }
               ?>

               </tbody>            
              </table>
      </div>
      
    </a>
  </div>
      
    </div>
    <br><br><br>
</div>
 <div class="container">

  <div class="row">

      <!-- monitored users -->
      <div class="col-sm-6">
          <p></p>
          <p>Application log summary</p>
          <ul class="list-group">
          <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                 <tr>
                  <th>Level</th>
                  <th>Count</th>
                 </tr>
               </thead>
               <tbody>
                <?php
               $sql = "SELECT level, COUNT(level) AS count FROM app GROUP BY level";
               $result = $conn->query($sql);

                while($row = mysqli_fetch_array($result)){
                  ?>
                  <tr>
                  <td><?php echo $row['level']; ?></td>
                  <td><?php echo $row['count']; ?></td> 
                  </tr>

                <?php }
               ?>
              </tbody>            
          </table>
          </ul>
      </div>

      <div class="col-sm-6">
      <p></p>
      <p>system log summary</p>
        <div class="card">
          <div class="card-body">
         
            <!-- recent offenses -->
            <div class="row">
              <div class="col-sm-10" style="border: 0px solid black;">
                    
                    <div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    
        <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script>
        $(document).ready(function () {
            showGraph();
        });


        function showGraph()
        {
            {
                $.post("graph.php",
                function (data)
                {
                    console.log(data);
                     var lev = [];
                    var tcount = [];

                    for (var i in data) {
                        lev.push(data[i].level);
                        tcount.push(data[i].total);
                    }

                    var chartdata = {
                        labels: lev,
                        datasets: [
                            {
                                label: 'System log count',
                                backgroundColor: '#49e2ff',
                                borderColor: '#46d5f1',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: tcount
                            }
                        ]
                    };

                    var graphTarget = $("#graphCanvas");

                    var piechart = new Chart(graphTarget, {
                        type: 'bar',
                        data: chartdata
                    });
                });
            }
        }
        </script>

      </div>   
              
            </div>

          </div>
        </div>
      </div>
    </div>
    <p><p>
    <div class="row">
      <div class ="col-sm">
        <div class="card">
          <div class="card-body">
          <?php include ('home_component.php');?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
					
				</div>			
			</div>
			<!-- /Page Wrapper -->
		
        </div>
		<!-- /Main Wrapper -->

		<!-- Reply Feedback Modal Start -->


		<!-- Reply Feedback Modal End -->
		
		<!-- jQuery -->
        <script src="assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		
		<!-- Datatables JS -->
		<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatables/datatables.min.js"></script>
		
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
		
		<!-- Custom JS -->
		<script  src="assets/js/script.js"></script>

		<script  src="assets/php/js/feedback.js"></script>
		
    </body>
</html>