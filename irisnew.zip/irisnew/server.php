<?php
include ('db.php');

$sql="SELECT COUNT(*) FROM `app`";
$res = $conn->query($sql);
$row=mysqli_fetch_array($res);

$sql1="SELECT COUNT(*) FROM `system`";
$res1 = $conn->query($sql1);
$row1=mysqli_fetch_array($res1);


$sql2="SELECT COUNT(*) FROM `adsecurity`";
$res2 = $conn->query($sql2);
$row2=mysqli_fetch_array($res2);

$sql3 = "SELECT level, COUNT(level), event_id FROM adsecurity WHERE event_id = '4720' ";
$result3 = $conn->query($sql3);
$row3=mysqli_fetch_array($result3);

$sql4 = "SELECT level, COUNT(level), event_id FROM adsecurity WHERE event_id = '4726' ";
$result4 = $conn->query($sql4);
$row4=mysqli_fetch_array($result4);

$sql5 = "SELECT timestamp, description FROM adsecurity WHERE event_id = '4660'";
$result5 = $conn->query($sql5);
$row5=mysqli_fetch_array($result5);
?>