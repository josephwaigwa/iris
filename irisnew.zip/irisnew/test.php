
<?php
class DB{
    public $servername = "localhost";
   public  $username = "root";
    public $dbname = "iris";
    public $password = "";
    public $conn;
    public $logs=array();
    public function __construct(){
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);


        if ($this->conn -> connect_errno) {
            echo "Failed to connect to MySQL: " . $conn -> connect_error;
            exit();
        }else{
            return $this->conn;
        }
    }



    public function getBaselines(){
        $query = "SELECT * FROM app";
        $level = '';
        $severity = array();
        $baselines = file_get_contents('timebaseline.json');

        $baseline_data = json_decode($baselines,true);
            
    //     foreach ($baseline_data as $key=> $data){
    //       print_r($data);
    //   //    if ($key==$row['level']){
      //        foreach($data as $level){
                   
      //            if($level['time']==$row['time']){//please check time comparison(DO THAT COMPARISON HERE,SIMPLY DO YOUR BASELINE CHECK ON THIS LINE) in php, w3schools
      //                $type= $level['type'];
      //                array_push($severity,$type);
      //            }
      //        }
      //    }
        // }


        $result = $this->conn->query($query);
        while($row=$result->fetch_assoc()){
            $level = $row['level'];
            $time = $row['time'];
            $type = "";

            if($time >= strtotime('23:59:00')){
                $type = 'Critical';
            }else if($time >= strtotime('22:00:00') && $time <= strtotime('23:58:59')){
                $type = 'High';
            }else if($time >= strtotime('17:01:00') && $time <= strtotime('21:59:59')){
                $type = 'Low';
            }

            array_push($this->logs,array($level, $type, $time));
        }
        // $this->logs=$severity;
        // return "GETTING BASELINES";
        // echo build_tabular_format($severity);
        
    }
    public function getErrorCounts(){
        $info_critical = 0;
        $info_high = 0;
        $info_low = 0;
        $error_critical = 0;
        $error_high = 0;
        $error_low = 0;
        $warning_critical = 0;
        $warning_high= 0;
        $warning_low = 0;
        //don't forget for each array element, level two index 0 is level,index 1 is type;
        foreach($this->logs as $log){
            if($log[0]=='Error' && $log[1]=='Critical'){
                $error_critical+=1;
            }else if($log[0]=='Error' && $log[1]=='High'){
                $error_high+=1;
                
            }else if($log[0]=='Error' && $log[1]=='Low'){
                $error_low+=1;
            }
        }
        return array($error_critical,$error_high,$error_low);
        // echo '<pre>'; print_r(array($error_critical,$error_high,$error_low)); echo '</pre>';;
    }
    public function getInformationCounts(){
        $info_critical = 0;
        $info_high = 0;
        $info_low = 0;
        $warning_critical = 0;
        $warning_high= 0;
        $warning_low = 0;
        //don't forget for each array element, level two index 0 is level,index 1 is type;
        foreach($this->logs as $log){
            if($log[0]=='Information' && $log[1]=='Critical'){
                $info_critical+=1;
            }else if($log[0]=='Information' && $log[1]=='High'){
                $info_high+=1;
                
            }else if($log[0]=='Information' && $log[1]=='Low'){
                $info_low+=1;
            }
        }
        return array($info_critical,$info_high,$info_low);
        // echo '<pre>'; print_r(array($error_critical,$error_high,$error_low)); echo '</pre>';;
    }
    public function getWarningCounts(){
        $info_critical = 0;
        $info_high = 0;
        $info_low = 0;
        $warning_critical = 0;
        $warning_high= 0;
        $warning_low = 0;
        //don't forget for each array element, level two index 0 is level,index 1 is type;
        foreach($this->logs as $log){
            if($log[0]=='Warning' && $log[1]=='Critical'){
                $warning_critical+=1;
            }else if($log[0]=='Warning' && $log[1]=='High'){
                $warning_high+=1;
                
            }else if($log[0]=='Warning' && $log[1]=='Low'){
                $warning_low+=1;
            }
        }
        return array($warning_critical,$warning_high,$warning_low);
        // echo '<pre>'; print_r(array($error_critical,$error_high,$error_low)); echo '</pre>';;
    }
    public function getErrors(){
        $errors = array();
        $query = "SELECT * FROM app WHERE level='error' LIMIT 20";
        $result = $this->conn->query($query);
        // $data=$result->fetch_assoc();
        while($row=$result->fetch_assoc()){
            array_push($errors,$row);
        }
        return $errors;
    }
    public function getInformation(){
        $query = "SELECT * FROM app WHERE level='information'";
        $result = $this->conn->query($query);
        $data=$result->fetch_assoc();
        return $data;
    }
    public function getWarnings(){
        $query = "SELECT * FROM app WHERE level='warning'";
        $result = $this->conn->query($query);
        $data=$result->fetch_assoc();
        return $data;
    }
}
?> 