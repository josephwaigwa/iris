<?php require_once 'assets/php/admin-header.php'; ?>
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Cases</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					<div class="container">
    <div class="row">
      <div class="col-sm">
        <hr>
      </div>
    </div>
    <div class="row">
      <div class="col-sm">
        <div class="card">
          <div class="card-body">
            
            <h2><b>Users & Files Cases.</b> </h2>
            <p>
            </p>
            <hr>
            <div class="row">
              <div class="col-sm">
              <?php
              include 'db.php';
               $sql = "SELECT level, COUNT(level), event_id FROM adsecurity WHERE event_id = '4720' ";
               $result = $conn->query($sql);
               $row=mysqli_fetch_array($result);
              ?>

                <h5>
                  Users created: <?php echo $row['COUNT(level)']?>
                  <!-- <span class="badge badge-info"><?php echo $row['COUNT(level)']?></span> -->
                </h5>
              </div>
              <div class="col-sm">
              <?php
              include 'db.php';
               $sql = "SELECT level, COUNT(level), event_id FROM adsecurity WHERE event_id = '4726' ";
               $result = $conn->query($sql);
               $row=mysqli_fetch_array($result);
              ?>
                <h5>
                  Users deleted: <?php echo $row['COUNT(level)']?>
                  <!-- <span class="badge badge-info"><?php echo $row['COUNT(level)']?></span> -->
                </h5>
              </div>
             
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

      <ul>
  <br><br><br>

  <div class="container">
    <li><a href="#"><p> User Created Alert<p></a> </li>
    <div class="row">
      <div class="col-sm">
      <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                 <tr>
                  <th>Timestamp</th>
                  <th>Description</th>
                 </tr>
               </thead>
               <tbody>
                <?php
               $sql = "SELECT timestamp, description FROM adsecurity WHERE event_id = '4720'";
               $result = $conn->query($sql);

                while($row = mysqli_fetch_array($result)){
                  ?>
                  <tr>
                  <td><?php echo $row['timestamp']; ?></td>
                  <td><?php echo $row['description']; ?></td> 
                  </tr>

                <?php }
               ?>
              </tbody>            
          </table>
      </div>
    </div>
  </div>
  <div class="container">
  <li><a href="#"><p> User Deleted Alert<p></a></li>
    <div class="row">
      <div class="col-sm">
      <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                 <tr>
                  <th>Timestamp</th>
                  <th>Description</th>
                 </tr>
               </thead>
               <tbody>
                <?php
               $sql = "SELECT timestamp, description FROM adsecurity WHERE event_id = '4726'";
               $result = $conn->query($sql);

                while($row = mysqli_fetch_array($result)){
                  ?>
                  <tr>
                  <td><?php echo $row['timestamp']; ?></td>
                  <td><?php echo $row['description']; ?></td> 
                  </tr>

                <?php }
               ?>
              </tbody>            
          </table>
      </div>
    </div>
  </div>
  <div class="container">
  <li><a href="#"><p> File Delete Alert<p></a></li>
    <div class="row">
      <div class="col-sm">
      <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                 <tr>
                  <th>Timestamp</th>
                  <th>Description</th>
                 </tr>
               </thead>
               <tbody>
                <?php
               $sql = "SELECT timestamp, description FROM adsecurity WHERE event_id = '4660'";
               $result = $conn->query($sql);

                while($row = mysqli_fetch_array($result)){
                  ?>
                  <tr>
                  <td><?php echo $row['timestamp']; ?></td>
                  <td><?php echo $row['description']; ?></td> 
                  </tr>

                <?php }
               ?>
              </tbody>            
          </table>
      </div>
    </div>
  </div>
  <div class="container">
  <li><a href="#"><p> File Access Alert<p></a></li>
    <div class="row">
      <div class="col-sm">
      <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                 <tr>
                  <th>Timestamp</th>
                  <th>Description</th>
                 </tr>
               </thead>
               <tbody>
                <?php
               $sql = "SELECT timestamp, description FROM adsecurity WHERE event_id = '4663'";
               $result = $conn->query($sql);

                while($row = mysqli_fetch_array($result)){
                  ?>
                  <tr>
                  <td><?php echo $row['timestamp']; ?></td>
                  <td><?php echo $row['description']; ?></td> 
                  </tr>

                <?php }
               ?>
              </tbody>            
          </table>
      </div>
    </div>
  </div>
					
				
					
				</div>			
			</div>
			<!-- /Page Wrapper -->
		
        </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		
		<!-- Datatables JS -->
		<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatables/datatables.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

		<!-- Custom JS -->
		<script  src="assets/js/script.js"></script>

		<script src="assets/php/js/deleteduser.js"></script>
		<script src="https://d3js.org/d3.v3.min.js"></script>

<script>
  // Set the dimensions of the canvas / graph
  var margin = {
                top: 30,
                right: 20,
                bottom: 30,
                left: 30
              },
              width = 380 - margin.left - margin.right,
              height = 200 - margin.top - margin.bottom;

  // Parse the date / time
  var parseDate = d3.time.format("%d-%b-%y").parse;

  // Set the ranges
  var x = d3.time.scale().range([0, width]);
  var y = d3.scale.linear().range([height, 0]);

  // Define the axes
  var xAxis = d3.svg.axis().scale(x).orient("bottom").ticks(5);

  var yAxis = d3.svg.axis().scale(y).orient("left").ticks(5);

  // Define the line
  var valueline = d3.svg.line()
      .x(function(d) { return x(d.date); })
      .y(function(d) { return y(d.x); });

  // Adds the svg canvas
  var svg = d3.select("#d3_main")
  .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
  .append("g")
      .attr("transform",
            "translate(" + margin.left + "," + margin.top + ")");

  // The new data variable.
var data = [
  {date: "1-May-12", x: 58.13},
  {date: "30-Apr-12", x: 68.13},
];

data.forEach(function(d) {
    d.date = parseDate(d.date);
    d.x = +d.x;
});

// The following code was contained in the callback function.
x.domain(data.map(function(d) { return d.date; }));
y.domain([0, d3.max(data, function(d) { return d.x; })]);

// Add the valueline path.
svg.append("path")
    .attr("class", "line")
    .attr("d", valueline(data));

// Add the X Axis
svg.append("g")
    .attr("class", "x axis")
    .attr("transform", "translate(0," + height + ")")
    .call(xAxis);

// Add the Y Axis
svg.append("g")
    .attr("class", "y axis")
    .call(yAxis);


</script>

<script src="js/scripts.js"></script>
		
    </body>
</html>